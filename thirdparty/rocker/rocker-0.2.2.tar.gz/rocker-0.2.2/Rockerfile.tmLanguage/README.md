# Rockerfile.tmLanguage

Rockerfile syntaxt highlighting for TextMate and Sublime Text.  
This repo (in it's current format) is kept around since it's tied to Sublime Text's package control.

## Install

### Sublime Text

Copy this directory into `"~/Library/Application Support/Sublime Text 3/Packages/User"`
