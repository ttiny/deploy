/*-
 * Copyright 2015 Grammarly, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package compose

import (
	"compose/config"
	"strings"
	"time"
	"util"

	"github.com/go-yaml/yaml"
	"github.com/grammarly/rocker/src/rocker/imagename"

	log "github.com/Sirupsen/logrus"
	"github.com/fsouza/go-dockerclient"
)

// Container object represents a single container produced by a rocker-compose spec
type Container struct {
	Id      string
	Image   *imagename.ImageName
	ImageId string
	Name    *config.ContainerName
	Created time.Time
	State   *ContainerState
	Config  *config.Container
	Io      *ContainerIo

	container *docker.Container
}

// State represents the state of a container.
type ContainerState struct {
	Running    bool
	Paused     bool
	Restarting bool
	OOMKilled  bool
	Pid        int
	ExitCode   int
	Error      string
	StartedAt  time.Time
	FinishedAt time.Time
}

// GetContainersFromConfig returns the list of Container objects from
// a spec Config object.
func GetContainersFromConfig(cfg *config.Config) []*Container {
	containers := make([]*Container, 0)
	for name, containerConfig := range cfg.Containers {
		if strings.HasPrefix(name, "_") {
			continue
		}
		containerName := config.NewContainerName(cfg.Namespace, name)
		containers = append(containers, NewContainerFromConfig(containerName, containerConfig))
	}
	return containers
}

// NewContainerFromConfig makes a single Container object from a spec Config object.
func NewContainerFromConfig(name *config.ContainerName, containerConfig *config.Container) *Container {
	container := &Container{
		Name: name,
		State: &ContainerState{
			Running: containerConfig.State.Bool(),
		},
		Config: containerConfig,
	}
	if containerConfig.Image != nil {
		container.Image = imagename.New(*containerConfig.Image)
	}
	return container
}

// NewContainerFromDocker converts a container object given by
// docker client to a local Container object
func NewContainerFromDocker(dockerContainer *docker.Container) (*Container, error) {
	cfg, err := config.NewFromDocker(dockerContainer)
	if err != nil {
		return nil, err
	}
	return &Container{
		Id:      dockerContainer.ID,
		Image:   imagename.New(dockerContainer.Config.Image),
		ImageId: dockerContainer.Image,
		Name:    config.NewContainerNameFromString(dockerContainer.Name),
		Created: dockerContainer.Created,
		State: &ContainerState{
			Running:    dockerContainer.State.Running,
			Paused:     dockerContainer.State.Paused,
			Restarting: dockerContainer.State.Restarting,
			OOMKilled:  dockerContainer.State.OOMKilled,
			Pid:        dockerContainer.State.Pid,
			ExitCode:   dockerContainer.State.ExitCode,
			Error:      dockerContainer.State.Error,
			StartedAt:  dockerContainer.State.StartedAt,
			FinishedAt: dockerContainer.State.FinishedAt,
		},
		Config:    cfg,
		container: dockerContainer,
	}, nil
}

// String returns container name
func (a Container) String() string {
	return a.Name.String()
}

// IsSameNamespace returns true if current and given containers are from same namespace
func (a *Container) IsSameNamespace(b *Container) bool {
	return a.Name.IsEqualNs(b.Name)
}

// IsSameKind returns true if current and given containers have same name,
// without considering namespace
func (a *Container) IsSameKind(b *Container) bool {
	// TODO: compare other properties?
	return a.Name.IsEqualTo(b.Name)
}

// IsEqualTo returns true if current and given containers are equal by
// all dimensions. It compares configuration, image id (image can be updated),
// state (running, craeted)
func (a *Container) IsEqualTo(b *Container) bool {
	// check name
	if !a.IsSameKind(b) {
		return false
	}

	// check configuration
	if !a.Config.IsEqualTo(b.Config) {
		log.Debugf("Comparing '%s' and '%s': found difference in '%s'",
			a.Name.String(),
			b.Name.String(),
			a.Config.LastCompareField())
		return false
	}

	// check image
	if a.ImageId != "" && b.ImageId != "" && a.ImageId != b.ImageId {
		log.Debugf("Comparing '%s' and '%s': image '%s' updated (was %s became %s)",
			a.Name.String(),
			b.Name.String(),
			a.Image,
			util.TruncateID(b.ImageId),
			util.TruncateID(a.ImageId))
		return false
	}

	// One of exit codes is always '0' since once of containers (a or b) is always loaded from config
	if a.Config.State.IsRan() && a.State.ExitCode+b.State.ExitCode > 0 {
		log.Debugf("Comparing '%s' and '%s': container should run once, but previous exit code was %d",
			a.Name.String(),
			b.Name.String(),
			a.State.ExitCode+b.State.ExitCode)
		return false
	}

	// check state
	if !a.State.IsEqualState(b.State) {
		log.Debugf("Comparing '%s' and '%s': found difference in state: Running: %t != %t",
			a.Name.String(),
			b.Name.String(),
			a.State.Running,
			b.State.Running)
		return false
	}

	return true
}

// IsEqualState returns true if current and given containers have the same state
func (a *ContainerState) IsEqualState(b *ContainerState) bool {
	return a.Running == b.Running
}

// CreateContainerOptions returns create configuration eatable by go-dockerclient
func (container *Container) CreateContainerOptions() (*docker.CreateContainerOptions, error) {
	apiConfig := container.Config.GetApiConfig()

	yamlData, err := yaml.Marshal(container.Config)
	if err != nil {
		return nil, err
	}

	// Copy labels because we want to assign some extra stuff
	labels := map[string]string{}
	for k, v := range apiConfig.Labels {
		labels[k] = v
	}
	labels["rocker-compose-id"] = util.GenerateRandomID()
	labels["rocker-compose-config"] = string(yamlData)

	apiConfig.Labels = labels

	return &docker.CreateContainerOptions{
		Name:       container.Name.String(),
		Config:     apiConfig,
		HostConfig: container.Config.GetApiHostConfig(),
	}, nil
}
